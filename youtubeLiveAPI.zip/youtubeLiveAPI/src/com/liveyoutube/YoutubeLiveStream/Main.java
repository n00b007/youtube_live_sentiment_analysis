package com.liveyoutube.YoutubeLiveStream;


public class Main {

    static String videoId = "hHW1oY26kxQ";

    public static void main(String[] args) {

        ListLiveChatMessages.main(new String[] {videoId}
        );
    }
}
